if ('mozLockOrientation' in screen) {
	var cls = document.documentElement.className,
		orient = 'portrait',
		match;
	if (cls && (match = cls.match(/orient-([a-z]+)/))) {
		orient = match[1];
	}
	if (!screen.mozLockOrientation(orient)) {
		console.warn('Could not lock screen to ' + orient);
	}
}