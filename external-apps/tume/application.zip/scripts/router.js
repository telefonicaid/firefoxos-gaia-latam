define([
  'backbone',
  'underscore',
  'zeptojs',
  'global',
  'views/index',
  'views/inbox',
  'views/login',
  'views/validate',
  'views/settings',
  'views/conversation'
], function (Backbone, _, zepto, global, IndexView, InboxView, LoginView,
  ValidateView, SettingsView, ConversationView) {
  'use strict';

  var $ = zepto;

  var Router = Backbone.Router.extend({
    initialize: function () {
      // All navigation that is relative should be passed through the navigate
      // method, to be processed by the router. If the link has a `data-bypass`
      // attribute, bypass the delegation completely.
      // (modified from https://github.com/tbranyen/backbone-boilerplate)
      $(document).on('click', 'a[href]:not([data-bypass])',
                     _.bind(this.clickInterceptor, this));
    },

    clickInterceptor: function (evt) {

      if (evt.defaultPrevented) {
        return;
      }

      // Get the absolute anchor href.
      var href = { prop: $(evt.currentTarget).prop('href'),
                   attr: $(evt.currentTarget).attr('href') };

      // Get the absolute root.
      var appRoot = '/';
      var root = location.protocol + '//' + location.host + appRoot;

      // Stop the default event to ensure the link will not cause a page
      // refresh.
      evt.preventDefault();

      if (href.prop.slice(0, root.length) === root) {
        // if it's relative
        // Remove initial '#' or '/' if present
        var whereToGo = href.attr.replace(/^[#\/]/, '');
        this.navigate(whereToGo, { trigger: true });
      } else {
        // if it's not relative
        // In our particular case, we don't want to enable ANY link outside
        // that does not have a data-bypass attribute. So do nothing here.
        console.log('Attempt to load url ' + href.prop);
      }
    },

    routes: {
      '':                         'index',
      'inbox':                    'inbox',
      'login':                    'login',
      'validate/:phoneNumber':    'validate',
      'settings':                 'settings',
      'conversation/:identifier': 'conversation'
    },

    inbox: function () {
      this.show(new InboxView({model: global.historyCollection}));
    },

    index: function () {
      this.show(new IndexView());
    },

    login: function () {
      this.show(new LoginView());
    },

    validate: function (phoneNumber) {
      this.show(new ValidateView({ phoneNumber: phoneNumber }));
    },

    settings: function () {
      this.show(new SettingsView());
    },

    conversation: function (identifier) {
      console.log('Creating conversation');
      // here we can cache/reuse views if needed
      // TODO: look in History for the right conversation based on identifier
      var c = global.historyCollection.findAndCreateConversation(identifier);
      if (c.get('messages').length === 0) {
        c.loadMessagesFromStorage();
      }
      c.set('isRead', true);
      var cView = new ConversationView({model: c});
      this.show(cView);
    },

    show: function (view) {
      if (this.currentView) {
        // We use these methods instead of .remove() because remove()
        // deletes the View main element
        this.currentView.stopListening();
        this.currentView.undelegateEvents();
        this.currentView.$el.empty();

        // Views can define a clear() method which should clean them for
        // avoiding memory leaks
        if (typeof this.currentView.clear !== 'undefined') {
          this.currentView.clear();
        }
      }

      this.currentView = view;
      this.currentView.render();
    }
  });

  return Router;
});
