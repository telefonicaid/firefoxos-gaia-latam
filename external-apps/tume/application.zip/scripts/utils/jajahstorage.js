// # Jajah Storage module
//
// This module allows to download and upload Blobs to Jajah in order to send
// images, audios and videos.
//
// It uses the xhr2 interface, which is available in modern browsers (including
// FirefoxOS).
//
// ## Usage
//
// * download a picture:
//
//     var download = JajahStorage.download(url, 'image/jpg');
//     download.on('load', function (imageBlob) {
//        // Create a <img> tag with the Blob
//        var img = $('<img>')
//          .attr('src', window.URL.createObjectURL(imageBlob));
//     });
//
// * upload a picture:
//
//     // Get the image blob from a mozActivity:
//     var pick = new MozActivity({name: "pick"});
//     pick.onsuccess = function () {
//       var imageBlob = this.result.blob;
//       var upload = JajahStorage.upload(imageBlob);
//       upload.on('complete', function(location) {
//          console.log('Image location: ' + location);
//       });
//     };
//
define([
  'backbone',
  'underscore',
  'global'
],
function (Backbone, _, global) {
  'use strict';

  return {
    download: function (url, mimeType) {
      var xhr = new XMLHttpRequest({
        mozSystem: true
      });
      var progress = {};
      _.extend(progress, Backbone.Events);

      xhr.open('GET', url, true);
      xhr.responseType = 'blob';
      xhr.overrideMimeType(mimeType);

      xhr.setRequestHeader('Authorization',
        'Bearer ' + global.client.getToken());

      xhr.addEventListener('load', function () {
        var _this = this;

        if (this.status < 300) {
          var blob = this.response;
          progress.trigger('complete', blob);
        } else {
          // Parse the response blob as plain text
          var reader = new FileReader();
          reader.readAsText(this.response, 'UTF-8');

          reader.onload = function (evt) {
            progress.trigger('error', _this.status, evt.target.result);
          };
          reader.onerror = function () {
            progress.trigger('error', _this.status, '');
          };
        }
      });

      xhr.addEventListener('error', function (err) {
        progress.trigger('networkerror', err);
      });

      xhr.addEventListener('progress', function (evt) {
        if (evt.lengthComputable) {
          progress.trigger('progress', evt.loaded, evt.total);
        }
      });

      xhr.send();

      return progress;
    },

    upload: function (blob) {
      var xhr = new XMLHttpRequest({
        mozSystem: true
      });
      var progress = {};
      _.extend(progress, Backbone.Events);

      xhr.open('POST', global.auth.get('storageUrl'), true);

      xhr.setRequestHeader('Authorization',
        'Bearer ' + global.client.getToken());

      xhr.addEventListener('load', function (evt) {
        if (this.status < 300) {
          progress.trigger(
            'complete', evt.target.getResponseHeader('location')
          );
        } else {
          progress.trigger('error', this.status, this.responseText);
        }
      });

      xhr.addEventListener('error', function (err) {
        progress.trigger('networkerror', err);
      });

      xhr.upload.addEventListener('progress', function (evt) {
        if (evt.lengthComputable) {
          progress.trigger('progress', evt.loaded, evt.total);
        }
      });

      xhr.send(blob);

      return progress;
    }
  };
});
