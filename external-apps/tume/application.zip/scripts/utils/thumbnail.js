define([], function () {
  'use strict';

  var DEFAULT_MAX_SIZE = 120;

  return {
    setMaxSize: function (maxSize) {
      this.maxSize = maxSize;
    },
    generate: function (imageBlob, callback) {
      var maxSize = this.maxSize || DEFAULT_MAX_SIZE;

      var fileReader = new FileReader();
      fileReader.readAsDataURL(imageBlob);

      fileReader.onload = function (evt) {
        var img = document.createElement('img');

        img.onload = function () {
          var width = img.width,
              height = img.height;

          var ratio = Math.min(maxSize / Math.max(height, width), 1);

          var c = document.createElement('canvas');
          c.width = width * ratio;
          c.height = height * ratio;

          var ctx = c.getContext('2d');
          ctx.drawImage(img, 0, 0, width * ratio, height * ratio);

          callback(null, c.toDataURL('image/jpeg').split('base64,')[1]);
        };

        img.onerror = function (err) {
          callback(err);
        };

        // The `src` of the image should be set after the event handler
        img.src = evt.target.result;
      };

      fileReader.onerror = function (evt) {
        callback(evt);
      };
    }
  };
});
