require.config({
  baseUrl: '/scripts/',
  paths: {
    zeptojs: '../components/zepto/zepto.min',
    underscore: '../components/underscore/underscore-min',
    backbone: '../components/backbone/backbone-min',
    handlebars: '../components/handlebars.js/dist/handlebars.runtime',
    rtc: 'vendor/ottcomms-rtc-web/rtc',
    libphonenumber: '../components/PhoneNumber.js'
  },
  shim: {
    'zeptojs': {
      exports: '$'
    },
    'underscore': {
      exports: '_'
    },
    'backbone': {
      deps: ['underscore', 'zeptojs'],
      exports: 'Backbone'
    },
    'handlebars': {
      exports: 'Handlebars'
    },
    'rtc/rtc': {
      exports: 'RTC',
      deps: ['rtc/sip', 'rtc/connection']
    },
    'libphonenumber/PhoneNumber': {
      exports: 'PhoneNumber',
      deps: ['libphonenumber/PhoneNumberMetaData']
    },
    'vendor/async-storage/async-storage': {
      exports: 'asyncStorage'
    }
  }
});

require([
  'backbone',
  'global',
  'models/auth',
  'collections/contacts',
  'router',
  'models/rtc',
  'models/geoposition',
  'collections/history',
  'templates/helpers',
  'models/history-fetcher'
], function (Backbone, global, Auth, Contacts, Router, Rtc, GeoPosition,
             HistoryCollection, HandlebarsHelpers, HistoryFetcher) {
  'use strict';

  global.router = new Router();
  global.auth = new Auth();
  global.geoPosition = new GeoPosition();
  global.rtc = new Rtc();
  global.contacts = new Contacts();
  global.historyFetcher = new HistoryFetcher();
  global.historyCollection = new HistoryCollection();

  HandlebarsHelpers.register();

  Backbone.history.start();

  // Update the position at startup
  //global.geoPosition.update();

  // Show alert box when there is an API error
  global.auth.on('error', function (err, message) {
    global.showMessage('API error', err, message);
  });

  // Check if the user has valid credentials
  global.auth.checkCredentials();
});
