define([
  'backbone',
  'global',
  'underscore',
  'models/contact',
  'zeptojs',
  'utils/phonenumber'
], function (Backbone, global, _, Contact, $, PhoneNumber) {
  'use strict';

  var Contacts = Backbone.Collection.extend({
    model: Contact,

    initialize: function () {
      this.sentContactNumbers = [];
      this.tuMeContacts = [];
      this.subscribeInterval = null;
      this.registeredToListenContacts = false;
      this.listenTo(global.auth, 'change:loggedIn', this.loggedInChanged);
      this.listenTo(global.rtc, 'subscribe', this.receivedSubscribe);
    },

    unregister: function () {
      this.sentContactNumbers = [];
      this.tuMeContactsDetails = [];
      this.tuMeContacts = [];
      this.reset();
    },

    registerContactChangeListener: function () {
      var _this = this;
      if (navigator.mozContacts) {
        this.registeredToListenContacts = true;
        navigator.mozContacts.oncontactchange = function () {
          _this.fetchAddressBookContacts(true);
        };
      }
    },

    receivedSubscribe: function (contacts) {
      this.tuMeContacts = contacts; // store contacts received
      this.matchContacts();
    },

    loggedInChanged: function (model, loggedIn) {
      if (loggedIn) {
        if (!this.registeredToListenContacts) {
          this.registerContactChangeListener();
        }
        this.periodicalStatusUpdate();
        this.fetchAddressBookContacts();
      } else {
        if (this.subscribeInterval) { clearInterval(this.subscribeInterval); }
        this.reset();
      }
    },

    /**
     * Fetch Address Book Contacts
     * @param  {boolean} force Force the execution of subscribe
     */
    fetchAddressBookContacts: function (force) {
      // If device does not support mozConcats, nothing to do
      if (!navigator.mozContacts) {
        this.addressBookContacts = [];
        global.rtc.subscribe();
        return;
      }

      var _this = this;

      this.addressBookDone = false;

      // See https://wiki.mozilla.org/WebAPI/ContactsAPI
      var request = navigator.mozContacts.find({
        sortBy: 'familyName',
        sortOrder: 'ascending'
      });

      request.onsuccess = function () {
        PhoneNumber.setBaseNumber(global.auth.get('msisdn'));

        request.result.forEach(function (result) {
          // result is an array of ContactField structure (see Contacts API)
          var firstName = (result.givenName) ? result.givenName[0] : null;
          var lastName = (result.familyName) ? result.familyName[0] : null;
          var email = (result.email) ? result.email[0] : null;
          var photo = (result.photo && result.photo.length > 0) ?
            result.photo[0] : null;

          if (result.tel) {
            result.tel.forEach(function (phone) {
              if (phone && phone.value) {
                var phoneNumber = PhoneNumber.parse(phone.value);
                if (phoneNumber !== null) {
                  var name = (firstName) ?
                  firstName :  PhoneNumber.format(phoneNumber.full);
                  var contactModel = new Contact({
                    'firstName': name,
                    'lastName': lastName,
                    'phone': phoneNumber.full,
                    'email': email,
                    'photo': photo,
                    'contactId': result.id
                  });
                  _this.add(contactModel);
                }
              }
            });
          }
          _this.addressBookDone = true;
        });
        _this.sendContactsToServer(force);
      };

      request.onerror = function () {
        console.log('Error fetching Address Book with mozContacts API');
      };
    },

    /**
     * Send Address Book contacts to the server
     * @param  {boolean} force Force the execution of subscribe
     */
    sendContactsToServer: function (force) {
      var _this = this;
      var contactsToSend = [];
      _this.models.forEach(function (contact) {
        if ($.inArray(contact.get('phone'), _this.sentContactNumbers) === -1) {
          _this.sentContactNumbers.push(contact.get('phone'));
          contactsToSend.push({
            /*jshint camelcase: false */
            'first_name': contact.get('firstName'),
            'last_name': contact.get('lastName'),
            'contact_id': contact.get('contactId'),
            'contact_phones': [
              {
                'phone_number': contact.get('phone')
              }
            ]
            /*jshint camelcase: true */
          });
        }
      });

      global.client.createContact(contactsToSend, true, function (err) {
        if (err) {
          console.log('error updating contacts');
        }
        global.rtc.subscribe(force);
      });
    },

    /**
     * Uses the data received from server to mark contacts as 'isTumeUser'
     */
    matchContacts: function () {
      // we need to have subscribe and address book completed
      this.tuMeContacts.forEach(this.matchOneContact, this);
      this.trigger('complete', this.models);
    },

    /**
     * Find the contact in the address Book and create an element in
     * the collection if finded
     * @param  stdObject tuMeContact Tu Me contact return by the subscribe
     * @param  Array addressBookContacts Address book contacts
     * @return result of the insertion
     */
    matchOneContact: function (tuMeContact) {
      var contact = this.findWhere({'phone': tuMeContact.id});
      if (contact) {
        contact.set('status', tuMeContact.status);
        contact.set('isTumeUser', true);
      }
    },

    /**
     * Order the coollection by first name then last name
     * @param  two models to compare A B
     * @return -1 if A before B, 0 if equal, 1 if after.
     */
    comparator: function (contactA, contactB) {
      var a = contactA.get('firstName') + ' ' + contactA.get('lastName');
      var b = contactB.get('firstName') + ' ' + contactB.get('lastName');
      return a.localeCompare(b);
    },

    /**
     * Get only the tume contacts from the collection
     * @return Array  Collection of tume contacts
     */
    getTumeContacts: function () {
      return this.where({'isTumeUser': true});
    },

    /**
     * Call every 5 minutes for user status update
     */
    periodicalStatusUpdate: function () {
      if (!this.subscribeInterval) {
        this.subscribeInterval = setInterval(function () {
          global.rtc.subscribe();
        }, 5 * 60 * 1000);
      }
    }

  });

  return Contacts;
});
