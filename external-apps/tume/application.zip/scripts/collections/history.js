define([
  'backbone',
  'global',
  'underscore',
  'vendor/async-storage/async-storage',
  'models/conversation',
  'models/message',
  'utils/phonenumber'
], function (Backbone, global, _, AsyncStorage, ConversationModel, MessageModel,
  PhoneNumber) {
  'use strict';

  return Backbone.Collection.extend({

    model: ConversationModel,

    initialize: function () {
      // Register to SIP: text message events
      this.listenTo(global.rtc, 'message:text', this._onTextReceived);
      // Register to SIP: image message events
      this.listenTo(global.rtc, 'message:image', this._onImageReceived);
      // Register to history
      this.listenTo(global.historyFetcher, 'messages', this._onHistoryFetched);

      // Indicates that we have already loaded all messages from local storage
      this.finishedLoading = false;
    },

    remove: function () {
      this.stopListening();
    },

    unregister: function () {
      this.forEach(function (conversation) {
        conversation.unregister();
      });

      this.reset();
    },

    _onImageReceived: function (from, meta, message) {
      // message = { caption, uri, thumbSrc }
      console.log('Received image: ' + message.caption);
      console.log('Received uri: ' + message.uri);
      // NOTE: In order to create an IMG element with the thumbnail use:
      // var img = $('<img>');
      // img.attr('src', message.thumbSrc);
      // (internally the thumbSrc is something like:
      //    data:image/png;base64,xxxxxxxxxx   i.e. it's embedded)
      // and then add it to whatever you need like $('body').append(img);
    },

    _onTextReceived: function (from, meta, inContent) {
      console.log('Received text from ', from, inContent, meta);

      // lookup (or create) ConversationModel
      var convInstance = this.findAndCreateConversation(from.msisdn);
      var message = new MessageModel({
        type: 'text',
        contents: inContent,
        from: from,
        meta: meta
      });

      var isRead = (!!global.router.currentView &&
        global.router.currentView.model === convInstance);
      convInstance.set({
        isOnline: false,
        isRead: isRead
      });
      convInstance.get('messages').add(message);
    },

    // We can receive periodically responses from server (request by
    // historyFetcher) that bring in messages that were sent when disconnected
    // and older messages.
    _onHistoryFetched: function (messages) {
      // messages is an array of
      // {
      //   from: from,
      //   to: to,
      //   meta: {
      //     type: type,
      //     date: d,
      //     commId: commId,
      //     delivered: delivered,
      //     deleted: deleted,
      //     read: read
      //   },
      //   content: content
      // };
      //
      // Our message model is:
      //  { from: { msisdn, displayName }, meta: { date, commId }, contents }

      console.log('Received messages from history: ', messages.length);
      var _this = this;
      messages.forEach(function (m) {
        if (!m.meta.deleted) {
          var me = global.auth.get('msisdn');
          var target;
          var status;
          if (me === m.to) {
            target = m.from;
            // TODO: Change status based on m.delivered
            status = 'sent';
          } else {
            target = m.to;
            status = 'sent';
          }

          // lookup (or create) ConversationModel
          var convInstance = _this.findAndCreateConversation(target);

          // Verify message is not already there
          var exists = convInstance.get('messages').find(function (message) {
            return (message.get('meta') &&
                message.get('meta').commId === m.meta.commId);
          });
          if (!exists) {
            var message = new MessageModel({
              type: 'text',
              contents: m.content,
              from: { msisdn: m.from },
              meta: { date: m.meta.date, commId: m.meta.commId },
              status: status
            });
            convInstance.get('messages').add(message);
          }
        } else {
          // TODO: Lookup conversation by MSISDN, then lookup
          // message by commId, then remove it
        }
      });
    },


    // Returns array of conversations between given dates
    _filterConversations: function (initialDate, endDate) {
      var models = this.models.filter(function (element) {
        var d = element.getAndUpdateLastMessageDate();
        if (d && (d >= initialDate) && (d < endDate)) {
          return element;
        }
        return undefined;
      });
      return models;
    },

    saveConversationList: function (callback) {
      var list = this.models.map(function (conversation) {
        return conversation.get('id');
      });

      var _this = this;
      AsyncStorage.setItem('conversations', list, function () {
        console.log('Saved conversation list');
        _this.trigger('history:save');
        if (callback) { callback(); }
      });
    },

    loadConversations: function () {
      if (this.finishedLoading) { // Only load on first use
        return;
      }

      var _this = this;
      var conversations = [];
      var count = 0;

      var enableRemoteLoading = function () {
        _this.finishedLoading = true; // now, we can load from remote
        global.historyFetcher.fetchMessages();
      };

      var loadAllMessages = function () {
        _this.reset(conversations);
        console.log('[history] Loading messages for ', conversations.length);
        _this.trigger('history:load');
        // TODO: Remove this and instead use an on-demand loading
        // mechanism based on keeping commId locally so we don't
        // clash with remote history. Until then we need this and
        // the this.finishedLoading flag.
        var finalCallback = _.after(conversations.length,
                                    enableRemoteLoading);
        conversations.forEach(function (c) {
          c.loadMessagesFromStorage(finalCallback);
        });
      };

      AsyncStorage.getItem('conversations', function (list) {
        if (!list || !list.length) {
          enableRemoteLoading();
          return;
        }
        list.forEach(function (id, index) {
          console.log('[history] About to load conversation ', id);
          ConversationModel.loadFromStorage(id, function (conversation) {
            conversations[index] = conversation;
            count++;
            if (count >= list.length) { loadAllMessages(); }
          });
        });
      });
    },

    // It receives a 'now' parameter to make sure we don't miss
    // dates because of time passing between related calls
    todaysConversations: function (now) {
      var endDate = new Date(now.getTime());
      endDate.setHours(endDate.getHours() + 1); // +1 for when exactly equal
      var initDate = new Date(now.getTime());
      // initDate = "0:0:0 of today"
      initDate.setHours(0);
      initDate.setMinutes(0);
      initDate.setSeconds(0);
      initDate.setMilliseconds(0);
      return this._filterConversations(initDate, endDate);
    },

    yesterdayConversations: function (now) {
      // end date = 0:0:0 of today
      var endDate = new Date(now.getTime());
      endDate.setHours(0);
      endDate.setMinutes(0);
      endDate.setSeconds(0);
      endDate.setMilliseconds(0);
      // init date = 0:0:0 of yesterday
      var initDate = new Date(now.getTime());
      initDate.setHours(0);
      initDate.setMinutes(0);
      initDate.setSeconds(0);
      initDate.setMilliseconds(0);
      initDate.setHours(-24);
      return this._filterConversations(initDate, endDate);
    },

    olderConversations: function (now) {
      // end date = 0:0:0 of yesterday
      var endDate = new Date(now.getTime());
      endDate.setHours(0);
      endDate.setMinutes(0);
      endDate.setSeconds(0);
      endDate.setMilliseconds(0);
      endDate.setHours(-24);
      // init date = beginning of time
      var initDate = new Date(2000, 1, 1);
      return this._filterConversations(initDate, endDate);
    },

    /* Look up a conversation in the history. If it's not there, create one
      and add it to the history.
    */
    findAndCreateConversation: function (identifier) {
      var c = this.findWhere({id : identifier});
      if (c) {
        return c;
      }

      var name;
      try {
        name = PhoneNumber.format(identifier);
      } catch (e) {
        name = identifier;
      }
      c = new ConversationModel({
        id : identifier,
        title: name
      });
      this.listenTo(c.get('messages'), 'add', this._purgeOldMessages);
      this.add(c);
      this.saveConversationList();
      return c;
    },

    _purgeOldMessages: function () {

      console.log('[history] Checking for purge');

      // Let's see if we are running out of space
      var count = 0;
      var oldest = { conversation : null, date : null };

      this.forEach(function (conversation) {
        var messages = conversation.get('messages');
        if (messages && messages.size() > 0) {
          count += messages.size();
          var oldestMessageInConversation = messages.at(0);
          var meta = oldestMessageInConversation.get('meta');
          if (!meta || !meta.date) {
            return;
          }
          if (!oldest.date || meta.date < oldest.date) {
            oldest.conversation = conversation;
            oldest.date = meta.date;
          }
        }
      });

      console.log('[history] Current history size: ', count);
      // This event is called AFTER element was added
      if (count >= global.maxStoredMessages) {
        // We know that oldest.conversation has a message and is the one
        // to purge
        if (oldest && oldest.conversation) {
          console.log('[history] Purging one message');
          var messages = oldest.conversation.get('messages');
          messages.remove(messages.at(0));
        }
      }
    },

    comparator: function (conversation) {
      if (!conversation) { return -1; }
      var date = conversation.getAndUpdateLastMessageDate();
      return date ? date : -1;
    }

  });
});
