define([
  'backbone',
  'global',
  'models/message'
], function (Backbone, global, MessageModel) {
  'use strict';

  return Backbone.Collection.extend({
    model: MessageModel,

    initialize: function () {
      this.listenTo(this, 'remove', this._messageRemoved);
    },

    fetch: function () {
    },

    _messageRemoved: function (model) {
      model.removeFromStorage();
    },

    /**
     * Order the coollection by date
     * @param  two models to compare A B
     * @return -1 if A before B, 0 if equal, 1 if after.
     */
    comparator: function (contact) {
      var meta = contact.get('meta');
      return meta && meta.date ? meta.date : -1;
    }
  });
});
