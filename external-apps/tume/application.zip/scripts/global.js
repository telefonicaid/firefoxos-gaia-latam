define([
  'vendor/tume-js-client/client',
  'views/alert-message'
], function (tumeClient, AlertMessage) {
  'use strict';

  var client = tumeClient.init({
    baseUrl: 'https://service.yarnapp.com',   /* production */
    appVersion : '1.0.1'
  });

  // This is only required while the API is finished
  // The actual web sockets proxy will be returned by the API per user
  // Until that is done, please configure here which one to use
  var clientConfig = {
    wsProxy: 'ws://195.235.93.155:443' // production
  };

  return {
    maxStoredMessages: 300, // Number of messages stored before they are removed
    client: client,
    clientConfig: clientConfig,
    showMessage: function (err, code, response) {
      var alertMessage = new AlertMessage();
      alertMessage.render({
        message: err,
        code: code,
        response: response
      });
    }
  };
});
