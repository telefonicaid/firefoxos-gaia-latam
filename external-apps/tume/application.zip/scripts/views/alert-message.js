define([
  'backbone',
  'zeptojs',
  'templates'
], function (Backbone, $, templates) {
  'use strict';

  var AlertMessage = Backbone.View.extend({
    template: templates['alert-message'],

    el: '#alert-message',

    render: function (options) {
      var _this = this;
      this.$el.html(this.template(options));
      window.setTimeout(function () {
        _this.$el.html('');
      }, 15000);
      return this;
    }
  });

  return AlertMessage;
});
