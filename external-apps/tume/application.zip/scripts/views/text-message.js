define([
  'backbone',
  'zeptojs',
  'global',
  'models/message',
  'templates'
], function (Backbone, $, global, Message, templates) {
  'use strict';

  return Backbone.View.extend({

    template: templates['text-message'],

    model: Message,

    events: {
      'click .resend': '_requestResend'
    },

    initialize: function () {
      this.listenTo(this.model, 'change:status', this._changeStatus);
    },

    clear: function () {
      this.stopListening();
    },

    render: function () {
      var newElement = this.template(this.model.toJSON());
      this.setElement(newElement);
    },

    _requestResend: function () {
      console.log('Request to send message', this.model.get('contents'));
      this.trigger('message:resend', this.model);
    },

    _changeStatus: function () {
      var oldElement = this.$el;
      this.render();
      oldElement.replaceWith(this.$el);
    }
  });
});
