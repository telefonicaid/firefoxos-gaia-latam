define([
  'backbone',
  'handlebars',
  'zeptojs',
  'global',
  'templates',
  'models/conversation',
  'models/message',
  'views/text-message',
  'views/compose-message'
], function (Backbone, Handlebars, $, global, templates, ConversationModel,
  MessageModel, TextMessageView, ComposeMessageView) {
  'use strict';

  var Conversation = Backbone.View.extend({

    el: '#main-page',

    template: templates.conversation,

    model: ConversationModel,

    events: {
      'click button.text': 'toggleComposeText',
      'click form#conversation-compose button.back': 'toggleComposeText'
    },

    initialize: function () {
      // Array of MessageViews for clearing and removing
      this.messageViews = [];

      this.listenTo(this.model.get('messages'), 'add', this._onAddMessage);
      this.listenTo(this.model.get('messages'), 'remove',
        this._onRemoveMessage);
      this.listenTo(this.model.get('messages'), 'reset', this.render);

      this.composeMessageView = new ComposeMessageView({
        model: new MessageModel()
      });

      this.listenTo(this.composeMessageView, 'compose:message:text',
        this._onComposeMessage);

      // this.listenTo(global.rtc, 'status', function (from, status) {
      //   console.log('from', from);
      //   console.log('status', status);
      // });
    },

    clear: function () {
      this.stopListening();
    },

    render: function () {
      this.$el.html(this.template(this.model.toJSON()));

      this.composeMessageView.render();
      this.$el.find('section[role=region]').append(this.composeMessageView.$el);

      this.$footer = this.$el.find('footer').first();
      this.$el.find('ul.messages').empty().append(this._renderMessages());

      this.scrollToLastMessage();
    },

    toggleComposeText: function () {
      this.$footer.toggleClass('typing');
    },

    scrollToLastMessage: function () {
      var wrapper = this.$el.find('.page-wrapper')[0];
      var list = this.$el.find('ul.messages')[0];
      if (wrapper && list) {
        wrapper.scrollTop = Math.max(0,
          list.clientHeight - wrapper.clientHeight);
      }
    },

    _onComposeMessage: function (message) {
      this.model.get('messages').push(message);
      this._sendMessage(message);
    },

    _sendMessage: function (message) {
      var _this = this;
      global.rtc.sendMessage(
        {
          to: this.model.get('id'),
          id: message.cid,
          message: message.get('contents')
        },
        function (error, commId) {
          _this._handleSentMessage(message, error, commId);
        }
      );
    },

    _resendMessage: function (message) {
      console.log('resending message', message.get('contents'));
      message.set('status', 'pending');
      this._sendMessage(message);
    },

    _handleSentMessage: function (message, error, commId) {
      if (error) { // error sending message
        message.set('status', 'unsent');
      }
      else { // message was sent successfully
        var meta = message.get('meta') || {};
        meta.commId = commId.value;
        message.set({
          status: 'sent',
          meta: meta
        });
      }

      message.saveToStorage();
    },

    _renderMessages: function () {
      var _this = this;

      this.messageViews = this.model.get('messages').map(function (message) {
        // TODO: create different views according to message types
        var view = new TextMessageView({model: message});
        view.render();
        _this.listenTo(view, 'message:resend', _this._resendMessage);
        _this.messageViews.push(view);
        return view;
      });

      return this.messageViews.map(function (view) { return view.$el[0]; });
    },

    _onAddMessage: function (message) {
      // TODO: create different views according to message types
      var view = new TextMessageView({model: message});
      view.render();
      this.listenTo(view, 'message:resend', this._resendMessage);
      this.messageViews.push(view);
      this.$el.find('ul.messages').append(view.$el);
      this.scrollToLastMessage();
    },

    _onRemoveMessage: function (message) {
      console.log('[conversation] Looking for message ', message);
      var newArray = [];
      this.messageViews.forEach(function (view) {
        if (view.model === message) {
          console.log('[conversation] Message found and removed');
          if (typeof view.clear !== 'undefined') {
            view.clear();
          }
          view.$el.remove();
          view.stopListening();
        } else {
          newArray.push(view); // add the rest
        }
      });
      this.messageViews = newArray;
    }

  });

  return Conversation;
});
