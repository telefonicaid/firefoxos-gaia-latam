define([
  'backbone',
  'zeptojs',
  'global',
  'models/contact',
  'templates'
], function (Backbone, $, global, contactModel, templates) {
  'use strict';

  var Contacts = Backbone.View.extend({
    tagName: 'li',

    template: templates.contact,

    model: contactModel,

    photoURL: null,

    render: function () {
      // link this contact to a conversation with it, if phone number, inbox
      // if no phone numbers are defined
      var phone = this.model.get('phone');
      var convURI = phone ? 'conversation/' + phone : 'inbox';
      var json = this.model.toJSON();

      if (!this.photoURL && this.model.get('photo') !== null) {
        this.photoURL = window.URL.createObjectURL(this.model.get('photo'));
      }
      json.photoURL = this.photoURL;
      json.conversationUri = convURI;
      this.$el.html(this.template(json));
      return this;
    },

    clear: function () {
      if (this.photoURL) {
        window.URL.revokeObjectURL(this.photoURL);
      }
    }
  });

  return Contacts;
});
