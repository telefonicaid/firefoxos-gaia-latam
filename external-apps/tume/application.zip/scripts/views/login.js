define([
  'backbone',
  'zeptojs',
  'global',
  'templates',
  'utils/phonenumber'
], function (Backbone, $, global, templates, PhoneNumber) {
  'use strict';

  var Login = Backbone.View.extend({

    el: '#main-page',

    template: templates.login,

    tosPage : templates.tos,

    privacyPage : templates.privacy,

    previousPages: [],

    currentPage: 'init',

    render: function () {
      this.$el.html(this.template());
      this.$el.removeClass().addClass('page init');
      this.$el.find('#tos-body').html(this.tosPage());
      this.$el.find('#privacy-body').html(this.privacyPage());
    },

    // TODO: shouldn't goToToS and goToPrivacy be actual routes?
    events: {
      'click #link-tos':          'gotoTOS',
      'click #link-privacy':      'gotoPrivacy',
      'submit #register':         'gotoConfirmation',
      'submit #register-conf':    'validate',
      'click .btn-back':          'back'
    },

    gotoTOS: function (evt) {
      evt.preventDefault();
      this.next('tos');
    },

    gotoPrivacy: function (evt) {
      evt.preventDefault();
      this.next('privacy');
    },

    gotoConfirmation: function (evt) {
      evt.preventDefault();
      var country = $(evt.target).find('select').val();
      var number = $(evt.target).find('input[name=msisdn]').val();
      var checkTos = $(evt.target).find('input[name=check-tos]');

      var international = this.checkPhoneNumber(number, country);
      if (!international) {
        return;
      }

      if (!checkTos.is(':checked')) {
        window.alert('Debe aceptar los términos');
        return;
      }

      var $confirmationForm = $('#register-conf');
      $confirmationForm.find('select').val(country);
      $confirmationForm.find('input[name=msisdn]').val(number);
      this.next('confirmation');
    },

    validate: function (evt) {
      var _this = this;
      evt.preventDefault();
      var country = $(evt.target).find('select').val();
      var number = $(evt.target).find('input[name=msisdn]').val();

      var international = this.checkPhoneNumber(number, country);
      if (!international) {
        return;
      }

      this.$el.find('section.intro > p').hide();
      this.toggleSpinner();

      var phoneNumber = international.full;

      // TODO: Get locale from the i18n object (or from the phone number)
      global.auth.register(phoneNumber, 'es-ES', function (err) {
        _this.toggleSpinner();
        if (err) {
          return _this.errorRegister();
        }
        global.router.navigate('validate/' + phoneNumber, { trigger: true });
      });

    },

    checkPhoneNumber: function (number, country) {
      if (!country) {
        window.alert('Por favor, seleccione un país.');
        return;
      }
      var international = PhoneNumber.parse(number, country);

      if (!international) {
        window.alert('El número de móvil no es válido.\n' +
        'Por favor, compruébelo y vuelva a intentarlo.');
        return;
      }
      return international;
    },

    next: function (nextPage) {
      this.previousPages.push(this.currentPage);
      this.$el.removeClass().addClass('page').addClass(nextPage);
      this.currentPage = nextPage;
    },

    back: function (evt) {
      evt.preventDefault();
      var previous = this.previousPages[this.previousPages.length - 1];
      this.$el.removeClass().addClass('page').addClass(previous);
      this.currentPage = previous;
      this.previousPages.pop(this.previousPages.length - 1);
    },

    toggleSpinner: function () {
      this.$el.find('.spinner').toggle();
      var button = this.$el.find('input[type=submit]');
      button.prop('disabled', !button.prop('disabled'));
    },

    errorRegister: function (err) {
      this.$el.find('section.intro > p').show();
      if (typeof err === 'object') {
        window.alert('Se ha producido un error al registrar su número de' +
          ' móvil.\n Por favor, compruebe su conectividad');
      } else if (err === 429) {
        window.alert('Se ha producido un error al registrar su número de' +
          ' móvil.\n Por favor, contacte con el servicio de asistencia');
      } else {
        window.alert('Se ha producido un error al registrar su número de' +
          ' móvil.\n Por favor, reinténtelo más tarde');
      }
    }
  });

  return Login;
});
