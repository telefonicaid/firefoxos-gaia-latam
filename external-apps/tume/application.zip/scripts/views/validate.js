define([
  'backbone',
  'zeptojs',
  'global',
  'templates',
  'utils/phonenumber'
], function (Backbone, $, global, templates, PhoneNumber) {
  'use strict';

  var Validate = Backbone.View.extend({

    el: '#main-page',

    template: templates.validate,

    render: function () {
      this.$el.removeClass().addClass('page validate');
      var internationalNumber = PhoneNumber.format(this.options.phoneNumber);
      this.$el.html(this.template({ phoneNumber: internationalNumber }));
    },

    events: {
      'submit #validate-form':          'validate',
      'click #call-me':                 'callMe',
      'keyup input[name=screen-name]':  'checkScreenName',
      'submit #screen-name-form':       'updateScreenName'
    },

    // Validate page functions

    callMe: function (evt) {
      evt.preventDefault();
      global.auth.register(this.options.phoneNumber, 'es-ES', function () {
        // TODO: Implement callback here
      });
    },

    checkPin: function (pin) {
      if (!pin || pin.length < 4) {
        window.alert('PIN no válido. Debe tener 4 dígitos');
        return false;
      }
      return true;
    },

    validate: function (evt) {
      var _this = this;
      evt.preventDefault();

      var pin = this.$el.find('input[name=validation-code]').val();

      if (this.checkPin(pin)) {
        this.showSpinner('validate-page');

        global.auth.validate(this.options.phoneNumber, pin, '', function (err) {

          _this.hideSpinner('validate-page');
          if (err) {
            window.alert('PIN no válido.');
            return;
          }
          _this.$el.removeClass().addClass('page screenname');
        });
      }
    },

    // Screen name page functions

    checkScreenName: function (evt) {
      evt.preventDefault();
      var name = $(evt.target).val();
      var button = $(evt.target).closest('form').find('input[type=submit]');
      button.prop('disabled', name.length < 4);
    },

    updateScreenName: function (evt) {
      evt.preventDefault();

      var _this = this;

      this.showSpinner('screenname-page');
      var screenName = $(evt.target).find('[name=screen-name]').val();
      global.auth.updateScreenName(screenName, function (err) {
        _this.hideSpinner('screenname-page');
        if (err) {
          window.alert('Su nombre de pantalla no puede estar vacío');
          return;
        }
        global.router.navigate('inbox', { trigger: true });
      });
    },

    // TODO: we are using the same method on 'login.js' -> refactor
    showSpinner: function (section) {
      var $section = this.$el.find('#' + section);

      $section.find('.spinner').show();
      $section.find('section.intro > p').hide();
      var button = $section.find('input[type=submit]');
      button.prop('disabled', true);
    },

    hideSpinner: function (section) {
      var $section = this.$el.find('#' + section);

      $section.find('.spinner').hide();
      $section.find('section.intro > p').show();
      var button = $section.find('input[type=submit]');
      button.prop('disabled', false);
    }
  });

  return Validate;
});