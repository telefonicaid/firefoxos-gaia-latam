define([
  'backbone',
  'zeptojs',
  'global',
  'templates'
], function (Backbone, $, global, templates) {
  'use strict';

  var Index = Backbone.View.extend({

    el: '#main-page',

    template: templates.index,

    _handleLogin: function () {
      var loggedIn = global.auth.get('loggedIn');
      var offline = global.auth.get('offlineLogged');
      if (offline) {//user is offline but has registered previously
        global.router.navigate('inbox', { trigger: true });
      } else {
        if (loggedIn) {
          global.router.navigate('inbox', { trigger: true });
        } else {
          global.router.navigate('login', { trigger: true });
        }
      }
    },

    render: function () {
      var _this = this;
      this.$el.html(this.template());
      global.auth.checkAppVersion(function () {
        var loggedIn = global.auth.get('loggedIn');
        if (loggedIn !== null) {
          return _this._handleLogin(global.auth);
        } else { // async database didn't finish
          _this.listenTo(global.auth, 'change:loggedIn', _this._handleLogin);
        }
      });
    }

  });

  return Index;
});
