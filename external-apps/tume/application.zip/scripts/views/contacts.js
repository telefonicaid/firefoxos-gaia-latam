define([
  'backbone',
  'zeptojs',
  'views/contact',
  'templates'
], function (Backbone, $, ContactView, templates) {
  'use strict';

  var Contacts = Backbone.View.extend({
    template: templates.contacts,
    tuMeContactsViews: [],

    initialize: function () {
      // re-render when list is updated after server response
      this.listenTo(this.model, 'complete', this.render);
      this.listenTo(this.model, 'reset', this.render);
    },

    render: function () {
      // clean up current contact subviews
      this.tuMeContactsViews.forEach(function (view) {
        view.clear();
      });
      this.tuMeContactsViews = [];

      this.$el.html(this.template());
      var tumeContacts = this.model.getTumeContacts();
      tumeContacts.forEach(this._renderContact, this);

      if (tumeContacts.length > 0) {
        this.$el.find('li#no-contact').remove();
      }

      return this;
    },

    _renderContact: function (contact) {
      // TODO: clean up old ContactView objects when they are removed
      var contactView = new ContactView({model: contact});
      this.$el.find('#contact-list').append(contactView.render().el);
      this.tuMeContactsViews.push(contactView);
    },

    clear: function () {
      this.tuMeContactsViews.forEach(function (contactView) {
        contactView.clear();
      });
      this.tuMeContactsViews = [];
    }
  });

  return Contacts;
});
