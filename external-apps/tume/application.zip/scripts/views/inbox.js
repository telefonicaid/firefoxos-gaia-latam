define([
  'backbone',
  'zeptojs',
  'global',
  'collections/history',
  'models/conversation',
  'views/mini-conversation',
  'templates',
  'views/contacts'
], function (Backbone, $, global, HistoryCollection, ConversationModel,
             MiniConversationView, templates, ContactsView) {
  'use strict';

  var Inbox = Backbone.View.extend({

    el: '#main-page',

    template: templates.inbox,

    model: HistoryCollection,

    events: {
      'click button.drawer': 'toggleDrawer'
    },

    initialize: function () {
      this.listenTo(this.model, 'add', this.render);
      this.listenTo(this.model, 'reset', this.render);

      this.listenTo(global.rtc, 'change:status', this._renderStatus);

      this.contactsView = new ContactsView({model: global.contacts});
      this.model.loadConversations();

      this.miniConversationViews = [];
      this.miniConversationViews['#inbox-today'] = [];
      this.miniConversationViews['#inbox-yesterday'] = [];
      this.miniConversationViews['#inbox-before'] = [];
    },

    // name = #inbox-today, #inbox-yesterday, #inbox-before
    _clearMiniConversations: function (name) {
      if (!this.miniConversationViews[name]) {
        this.miniConversationViews[name] = [];
        return;
      }
      this.miniConversationViews[name].forEach(function (miniC) {
        miniC.remove();
        miniC.clear();
        miniC.stopListening();
      });
    },

    // The sections for Today, Yesterday, Before are all initially
    // hidden. If a conversation exists in a section it is visible.
    _populateSection: function (name, conversations) {

      this._clearMiniConversations(name);
      var section = this.$el.find(name).first();
      var list = section.find('ul').first();
      if (conversations.length !== 0) {
        this.$el.find('#no-conversations').hide();
        section.show();
      }
      for (var i = 0; i < conversations.length; i++) {
        var mc = new MiniConversationView({ el: $('<li>'),
                                            model: conversations[i] });
        mc.render();
        list.append(mc.$el);
        this.miniConversationViews[name].push(mc);
      }
    },

    _renderStatus: function () {
      var status = global.rtc.get('status');

      if (status) {
        this.$el.find('#presence').removeClass().addClass(status).html(
        this._translateStatus(status));
      }
    },

    render: function () {
      // TODO: Cache the rendered element
      // - Record timestamp of last rendering (division between today/yesterday
      //  /etc) and re-render only if 24h have passed, or something like that..
      // - note: don't use new Date(), use setTimeout to prevent bugs due to
      // time changes, time zones, etc

      var status = global.rtc.get('status');
      status = (status) ? this._translateStatus(status) : '';

      this.$el.html(this.template({
        status: global.rtc.get('status') || '',
        statusTxt : status
      }));

      var now = new Date();
      this._populateSection('#inbox-today',
          global.historyCollection.todaysConversations(now));
      this._populateSection('#inbox-yesterday',
          global.historyCollection.yesterdayConversations(now));
      this._populateSection('#inbox-before',
          global.historyCollection.olderConversations(now));

      this.$inboxContainer = this.$el.find('section.drawer').first();

      this.$('#contacts .page-wrapper').html(this.contactsView.render().$el);
    },

    toggleDrawer: function (event) {
      event.preventDefault();
      var state = this.$inboxContainer.attr('data-state') === 'drawer' ?
        'none' : 'drawer';
      this.$inboxContainer.attr('data-state', state);
    },

    clear: function () {
      this.contactsView.clear();
      for (var key in this.miniConversationViews) {
        this._clearMiniConversations(key);
      }
    },

    _translateStatus : function (status) {
      //TODO get from properties
      status = status.toLowerCase();
      var newStatus = 'desconectado';
      if (status === 'online') {
        newStatus = 'conectado';
      } else if (status === 'offline') {
        newStatus = 'desconectado';
      } else if (status === 'connecting') {
        newStatus = 'conectando';
      }
      return newStatus;
    }
  });

  return Inbox;
});
