define([
  'backbone',
  'zeptojs',
  'global',
  'templates',
  'vendor/async-storage/async-storage'
], function (Backbone, $, global, templates, AsyncStorage) {
  'use strict';

  var Settings = Backbone.View.extend({
    el: '#main-page',

    template: templates.settings,

    tosPage : templates.tos,

    privacyPage : templates.privacy,

    events: {
      'click #unregister' : 'unregister',
      'click #showToS' :    'showTerms',
      'click #showPrivacy': 'showPrivacy',
      'click .btn-back':    'showSettings'
    },

    initialize: function () {
    },

    showSettings: function () {
      this.$el.removeClass().addClass('page settings');
    },

    showTerms: function (evt) {
      evt.preventDefault();
      if (this.$el.find('#tos-body').is(':empty')) {
        this.$el.find('#tos-body').html(this.tosPage());
      }
      this.$el.removeClass().addClass('page tos');
    },

    showPrivacy: function (evt) {
      evt.preventDefault();
      if (this.$el.find('#privacy-body').is(':empty')) {
        this.$el.find('#privacy-body').html(this.privacyPage());
      }
      this.$el.removeClass().addClass('page privacy');
    },

    unregister: function (evt) {
      evt.preventDefault();

      // TODO: localise this string
      if (window.confirm('Usa esta opción sólo si quieres desvincular TU Me' +
        ' de este dispositivo para poder registrarte en otro diferente.' +
        ' Si sólo quieres desconectarte, vuelve al menú principal de tu' +
        ' teléfono y Tu Me entrará en reposo')) {
        this._unregisterDevice();
      }

    },

    render: function () {
      this.$el.html(this.template({ version: global.client.getAppVersion() }));
      this.showSettings();
    },

    _unregisterDevice: function () {
      global.auth.logout();
      AsyncStorage.clear(function () { // TODO: add spinning wheel
        global.contacts.unregister();
        global.historyCollection.unregister();
        global.router.navigate('login', { trigger: true });
        window.location.reload(true);
      });
    }
  });

  return Settings;
});
