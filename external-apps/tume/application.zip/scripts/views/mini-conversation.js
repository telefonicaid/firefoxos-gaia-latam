define([
  'backbone',
  'zeptojs',
  'global',
  'models/conversation',
  'templates'
], function (Backbone, $, global, Conversation, templates) {
  'use strict';

  return Backbone.View.extend({

    template: templates['mini-conversation'],

    model: Conversation,

    events: {
      'click li > a' : 'openConversation'
    },

    initialize: function () {
      this.photoURL = null;
      this.listenTo(this.model, 'change', this.statusChanged);
      var messages = this.model.get('messages');
      if (messages) {
        this.listenTo(messages, 'add', this.statusChanged);
      }
    },

    statusChanged: function () {
      // render in current element
      if (this.$el) {
        var oldElement = this.$el;
        this.render();
        oldElement.replaceWith(this.$el);
      }
    },

    render: function () {
      var json = this.model.toJSON();
      if (!this.photoURL) {
        // locate contact and see if it's got an image
        var contact = global.contacts
                      .findWhere({ phone: this.model.get('id') });
        if (contact && contact.get('photo')) {
          this.photoURL = window.URL.createObjectURL(contact.get('photo'));
        }
      }
      json.photoURL = this.photoURL;
      var newElement = this.template(json);
      this.setElement(newElement);
    },

    openConversation: function (event) {
      event.preventDefault();
      global.router.navigate('conversation/' + this.model.get('id'),
        {trigger: true});
    },

    clear: function () {
      if (this.photoURL) {
        window.URL.revokeObjectURL(this.photoURL);
      }
    }
  });

});
