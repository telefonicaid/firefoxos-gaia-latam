// # RTC model
// This model is responsible of creating and mantaining the RTC connection to
// the SIP server, and trigger the appropiate events from the server.
//
// ## Properties
//
// * `status`: The status of the SIP connection. Can be can be 'online',
//   'offline' and 'connecting'.
//
// ## Methods
// * `initialize()`: the constructor only initializes the OTTCOMMS library
//   and starts listening to its events
//
// * `register(user, password)`: Logs into the SIP server. It changes the status
//   to `connecting` until the connection is established (then it goes to
//   `online`).
//
// * `close()`: Closes the connection to the SIP server and sets the status
//   to `offline`.
//
// * `subscribe()`: Asks for user's contacts presence info to the SIP server.
//
// * `sendMessage(options{id, to, message}, callback{err, commId})`:
//   Sends a text message to the specified destination. If there is an error,
//   `err` will contain the SIP error code.
//
// * `sendImage(options{id, to, caption, storageUrl, thumbnail},
//    callback{err, commId})`: Sends an image to the specified destination. If
//    there is an error, `err` will contain the SIP error code.
//
// ## Events
//
// ### Inbound events
//
// **global.auth change:loggedIn**: executes `register()` or `close()`
// depending on the loggedIn value
//
// **ottcomms connected**: executes `subscribe()` and sets status to `online`
//
// **ottcomms disconnected**: sets status to `offline`
//
// **ottcomms subscribe**: triggers `subscribe` event
//
// **ottcomms message**: triggers `message` and `message:<type>` events
//
// ### Outbound events
//
// **change:status**: when the status of the connection with the SIP server
// changes
//
// **subscribe (contacts)**: when the SIP server sends updated info about
// contacts presence. contacts format:
//     [ { id (phone number), status ("online" or "offline") } ]
//
// **message** (from, meta, message): when receiving any type of message.
// Format of from and meta params:
//     { from: { msisdn, displayName }, meta: { type, date, commId} }
//
// **message:text (from, meta, message)**: text message received.
//
// **message:location (from, meta, location)**: location received. Location
// format:
//     { coords: {lat, long}, address }
//
// **message:image (from, meta, image)**: image received. Image
// following format:
//     { caption, uri, thumbSrc }
//
// **message:audio (from, meta, audio)**: audio received. audio has the
// following format:
//     { uri, duration, mimeType }
//
// **status (from, status)**: message status received. Status has the
// following format:
//     { commId, status ("delivered" or "displayed") }
//
// **typing:active (from, typing)**: typing event received. typing has the
// following format:
//     { state: "active" }
//
// **typing:idle (from, typing)**: typing event received. typing has the
// following format:
//     { state: "idle" }


define([
  'backbone',
  'zeptojs',
  'global',
  'rtc/rtc'
], function (Backbone, $, global, RtcLibrary) {
  'use strict';

  // In seconds
  var SUBSCRIBE_MIN_INTERVAL = 300;
  var TYPING_EVENTS_TIMEOUT = 5;
  var SEND_MESSAGES_TIMEOUT = 60;

  var Rtc = Backbone.Model.extend({
    defaults: function () {
      return {
        // Status can be 'online', 'offline' and 'connecting'
        status: 'offline',
        sipDomain: 'yarnapp.com',
        // TODO: Check about wss??
        sipProxy: 'ws://195.235.93.155:443',
        headers: {
          'Comm-Notifications': 'delivered, displayed',
          'Comm-Logging': 'on'
        },
        _sentMessages: {}
      };
    },

    initialize: function () {
      var _this = this;

      // Initialize RTC client
      this.client = new RtcLibrary.RtcClient();

      // Start/Stop SIP session when the user logs in or logs out
      this.listenTo(global.auth, 'change:loggedIn', function (auth, loggedIn) {
        if (loggedIn === true) {
          var sipConfig = global.auth.get('sipCredentials');

          _this.set('sipDomain', sipConfig.domain);
          _this.set('sipProxy', sipConfig.server);
          _this.register(sipConfig.username, sipConfig.password);
        } else {
          _this.logout();
        }
      });

      // Bindings to OttComms-RTC events
      this.listenTo(this.client, 'connected', function () {
        _this.set('status', 'online');
      });

      this.listenTo(this.client, 'disconnected', function () {
        _this.set('status', 'offline');
      });

      this.listenTo(this.client, 'subscribe', function (client, message) {
        var content = _this._parse.subscribe(message);

        _this.trigger('subscribe', content);
      });

      this.listenTo(this.client, 'message', function (client, message) {
        var from = _this._getMessageSource(message);
        var type = _this._getMessageType(message);
        var content = _this._parse[type](message);

        // Split typing events into two different events
        if (type === 'typing') {
          type = type + ':' + content.state;
          _this._registerTypingEvent(content.state, from);
        }

        if (['location', 'audio', 'image', 'text'].indexOf(type) !== -1) {
          // Get metadata of the message
          var meta = _this._getMessageMeta(message);
          meta.type = type;

          _this.trigger('message message:' + type, from, meta, content);
          _this.trigger('typing:idle', from, { state: 'idle' });
        } else {
          _this.trigger(type, from, content);
        }
      });

      this.listenTo(global.geoPosition, 'change', this._syncGeoposition);
      this._syncGeoposition(global.geoPosition);

      this.listenTo(this.client, 'status', function (client, message) {
        var errorCode = message.code < 300 && message.code > 199 ?
          null : message.code;
        var commId = message.headers['comm-id'];
        var messageId = message.opaque;

        var callback = _this.get('_sentMessages')[messageId];

        if (callback) {
          delete _this.get('_sentMessages')[messageId];
          callback(errorCode, commId);
        }
      });
    },

    register: function (username, password) {
      if (this.get('status') !== 'offline') {
        return;
      }
      this.set('status', 'connecting');
      this.client.connect({
        username: username,
        password: password,
        domain: this.get('sipDomain'),
        proxy: this.get('sipProxy')
      });
    },

    logout: function () {
      this.client.disconnect();
      this.set('status', 'offline');
    },

    close: function () {
      this.logout();
      this.stopListening();
      this.set('_sentMessages', {});
    },

    sendMessage: function (options, callback) {
      var headers = this.get('headers');
      headers['Comm-Type'] = 'text';
      headers['content-type'] = 'text/plain; charset=UTF-8';
      if (options.id) {
        headers['Message-Id'] = options.id;
      }

      if (this.get('status') !== 'online') {
        if (callback && typeof callback === 'function') {
          setTimeout(function () {
            callback(408);
          }, 1000);
        }
        return;
      }

      var messageId = this.client.createUUID4();

      this._addSentMessage(messageId, callback);

      this.client.sendMessage({
        content: options.message,
        destination: options.to,
        headers: headers,
        opaque: messageId
      });
    },

    sendImage: function (options, callback) {
      var headers = this.get('headers');
      headers['Comm-Type'] = 'image';
      headers['content-type'] = 'application/external-content+xml';
      if (options.id) {
        headers['Message-Id'] = options.id;
      }

      // This is a little tricky... We are generating the correct XML using
      // the DOM parser to ensure that the XML is well formed even with strange
      // captions
      var doc = (new DOMParser()).parseFromString(
        '<external-content></external-content>',
        'application/xml'
      );

      var elements = [
        { tagName: 'caption', value: options.caption },
        { tagName: 'uri', value: options.storageUrl },
        { tagName: 'mime-type', value: 'image/jpeg' },
        { tagName: 'thumbnail', value: options.thumbnail }
      ];

      elements.forEach(function (el) {
        var element = doc.createElement(el.tagName);
        element.appendChild(doc.createTextNode(el.value));
        doc.documentElement.appendChild(element);
      });

      var xmlMessage = (new XMLSerializer()).serializeToString(doc);
      var messageId = this.client.createUUID4();

      this._addSentMessage(messageId, callback);

      this.client.sendMessage({
        content: xmlMessage,
        destination: options.to,
        headers: headers,
        opaque: messageId
      });
    },

    subscribe: function (force) {
      var _this = this;

      if (this.get('status') !== 'online') {
        this.listenTo(this, 'change:status', function (model, status) {
          if (status === 'online') {
            _this.stopListening(_this, 'change:status', this);
            _this.subscribe();
          }
        });
        return;
      }

      if (this.notAllowedToSubscribe && !force) {
        return;
      }
      this.notAllowedToSubscribe = true;

      window.setTimeout(function () {
        _this.notAllowedToSubscribe = false;
      }, SUBSCRIBE_MIN_INTERVAL * 1000);

      this.client.subscribe({
        headers: {
          'Accept': 'application/jj-presence+xml'
        }
      });
    },

    _addSentMessage: function (messageId, callback) {
      var _this = this;

      if (typeof callback === 'function') {
        // Store callback to be called when we receive the response
        this.get('_sentMessages')[messageId] = callback;

        // Add a time
        setTimeout(function () {
          if (_this.get('_sentMessages')[messageId]) {
            delete _this.get('_sentMessages')[messageId];
            callback(408);
          }
        }, SEND_MESSAGES_TIMEOUT * 1000);
      }
    },

    _syncGeoposition: function (model) {
      var latitude = model.get('latitude');
      var longitude = model.get('longitude');
      if (latitude !== null && typeof latitude !== 'undefined') {
        this.get('headers').GeoPosition = latitude + ' ' + longitude;
      }
    },

    _registerTypingEvent: function (state, from) {
      var _this = this;

      if (this.typingTimeout) {
        window.clearTimeout(this.typingTimeout);
      }

      if (state === 'active') {
        this.typingTimeout = window.setTimeout(function () {
          _this.trigger('typing:idle', from, { state: 'idle'});
        }, TYPING_EVENTS_TIMEOUT * 1000);
      }
    },

    _getMessageSource: function (message) {
      var msisdn,
          displayName;
      if (message.source.indexOf('<') === -1) {
        msisdn = message.source.split(':')[1].split('@')[0];
        displayName = '';
      } else {
        msisdn = message.source.split('<')[1].split(':')[1].split('@')[0];
        displayName = message.source.split('<')[0].trim();
      }
      return {
        msisdn: msisdn,
        displayName: displayName
      };
    },

    _getMessageType: function (message) {
      if (message.headers['comm-type']) {
        return message.headers['comm-type'];
      } else if (message.headers['content-type'] ===
        'application/jj-comm-notification+xml') {
        return 'status';
      }
    },

    _getMessageMeta: function (message) {
      return {
        date: new Date(),
        commId: message.headers['comm-id']
      };
    },

    _parse: {
      text: function (message) {
        return message.content;
      },
      location: function (message) {
        var content = $(message.content);
        var coords = content.find('coordinates').text();
        return {
          coords: {
            latitude: coords.split(' ')[0],
            longitude: coords.split(' ')[1]
          },
          address: content.find('address').text()
        };
      },
      status: function (message) {
        var content = (new DOMParser()).parseFromString(
          message.content, 'application/xml'
        );
        return {
          commId: content.querySelector('comm-id').textContent,
          status: content.querySelector('status *').nodeName.toLowerCase()
        };
      },
      image: function (message) {
        // Using DOMParser, because Zepto parses it as HTML and caption
        // tag is not recognized correctly
        var content = (new DOMParser()).parseFromString(
          message.content, 'application/xml'
        );
        return {
          caption: content.querySelector('caption').textContent,
          uri: content.querySelector('uri').textContent,
          thumbSrc: 'data:' + content.querySelector('mime-type').textContent +
            ';base64,' + content.querySelector('thumbnail').textContent
        };
      },
      audio: function (message) {
        var content = $(message.content);
        return {
          uri: content.find('uri').text(),
          duration: content.find('duration').text(),
          mimeType: content.find('mime-type').text()
        };
      },
      typing: function (message) {
        var content = (new DOMParser()).parseFromString(
          message.content, 'application/xml'
        );

        var state = 'idle';
        if (content.querySelector('state').textContent === 'start') {
          state = 'active';
        }

        return {
          state: state
        };
      },
      subscribe: function (message) {
        var content = (new DOMParser()).parseFromString(
          message.content, 'application/xml'
        );
        var contacts = [];
        content = content.querySelectorAll('contact');
        for (var i = 0; i < content.length; i++) {
          var contact = content[i];
          contacts.push({
            id: contact.attributes.id.textContent,
            status: contact.querySelector('status').textContent
          });
        }
        return contacts;
      }
    }
  });

  return Rtc;
});
