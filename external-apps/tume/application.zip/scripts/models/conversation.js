define([
  'backbone',
  'underscore',
  'global',
  'collections/messages',
  'models/message',
  'vendor/async-storage/async-storage'
], function (Backbone, _, global, MessagesCollection, MessageModel,
  AsyncStorage) {
  'use strict';

  var Conversation = Backbone.Model.extend({

    idAttribute: 'id', /* phone number for 1-to-1 chats, long for groups */

    defaults: function () {
      return {
        'title' : 'Untitled',
        'lastMessage' : '',
        'isRead' : true,
        'isOnline' : false,
        'messages' : new MessagesCollection(),
        'date': new Date(),
        'counter': 0,
        'messageKeys': []
      };
    },

    initialize: function () {
      this.listenTo(this.get('messages'), 'reset', this.updateLastMessage);
      this.listenTo(this.get('messages'), 'add', this.updateLastMessage);
      this.listenTo(this.get('messages'), 'add', this._onAddMessage);

      var contact = this._lookupContact();
      if (!contact) {
        // try it again later
        this.listenTo(global.contacts, 'add', this._lookupContact);
      }
    },

    unregister: function () {
      this.get('messages').forEach(function (message) {
        message.unregister();
      });

      this.get('messages').reset();
    },

    updateLastMessage: function () {
      var messages = this.get('messages');
      if (messages && messages.size()) {
        var last = messages.at(messages.size() - 1);
        if (last.get('type') === 'text') {
          this.set('lastMessage', last.get('contents'));
        }
      }
    },

    saveToStorage: function (callback) {
      var key = this.getStorageKey();
      var _this = this;
      AsyncStorage.setItem(key, this._serialize(), function () {
        console.log('Saved conversation', key);
        _this.trigger('conversation:save', _this);
        if (callback) { callback(); }
      });
    },

    loadMessagesFromStorage: function (callback) {
      var _this = this;
      var messages = [];
      var count = 0;
      var invalidIndexes = [];

      this.get('messageKeys').forEach(function (key) {
        MessageModel.loadFromStorage(key, function (message) {
          if (message) {
            messages.push(message);
          } else {
            invalidIndexes.push(key);
          }

          count++;
          if (count >= _this.get('messageKeys').length) {
            _this.get('messages').reset(messages);

            // Cleanup if we found messages that are no longer in the database
            var newKeys = _this.get('messageKeys').filter(function (element) {
              return (invalidIndexes.indexOf(element) === -1);
            });
            _this.set('messageKeys', newKeys);

            if (callback) { callback(); }
          }
        });
      });
    },

    getStorageKey: function () {
      return 'conv:' + this.get('id');
    },

    _serialize: function () {
      var attr = _.clone(this.attributes);
      delete attr.messages;
      return attr;
    },

    _onAddMessage: function (message) {
      var counter = this.get('counter');

      message.set({'conversationId' : this.get('id'),
        'counter' : counter});
      message.saveToStorage();
      this.get('messageKeys').push(message.getStorageKey());

      counter += 1;

      this.set({
        counter: counter,
        lastMessage: message.get('contents')
      });

      this.saveToStorage();
      // TODO: delete old messages so we are only storing last N messages
    },

    getAndUpdateLastMessageDate: function () {
      var messages = this.get('messages');
      var lastMessage = (messages && messages.size()) ?
                          messages.at(messages.size() - 1) : undefined;
      var date = lastMessage ? lastMessage.get('meta').date : this.get('date');
      date = date ? date : new Date(2000, 1, 1); // default to 'very old'
      this.set('date', date); // this is needed to place it in inbox while
                              // loading from storage and messages haven't yet
                              // been loaded
      return date;
    },

    _onContactStatusChanged: function (model, value) {
      this.set('isOnline', (value === 'online'));
      this.set('title', model.getFormattedName() || model.get('phone'));
    },

    _lookupContact: function () {
      var contact = global.contacts.findWhere({phone: this.get('id')});
      if (contact) {
        // set the initial status
        this._onContactStatusChanged(contact, contact.get('status'));
        // listen for changes
        this.listenTo(contact, 'change:status', this._onContactStatusChanged);
        this.stopListening(global.contacts, 'add', this._lookupContact);
      }
      return contact;
    }

  }, {
    // static methods and vars
    loadFromStorage: function (id, callback) {
      var key = 'conv:' + id;
      AsyncStorage.getItem(key, function (value) {
        console.log('[conversation] Loading conversation', key,
          (value ? 'OK' : 'FAILED'));

        if (!value) {
          callback(null);
        } else {
          var c = global.historyCollection.findAndCreateConversation(id);
          c.set(value);
          callback(c);
        }
      });
    }
  });

  return Conversation;
});
