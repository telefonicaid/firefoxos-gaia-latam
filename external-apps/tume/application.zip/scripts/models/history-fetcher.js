define([
  'backbone',
  'global',
  'vendor/async-storage/async-storage'
], function (Backbone, global, AsyncStorage) {
  'use strict';

  var HistoryFetcher = Backbone.Model.extend({

    defaults: function () {
      return {
        itemsPerPage: 100,
        lastVersion: 0,
        fetching: false
      };
    },

    initialize: function () {
      var _this = this;

      AsyncStorage.getItem('history.lastVersion', function (lastVersion) {
        _this.set({ lastVersion: lastVersion }, { trigger: false });

        _this.listenTo(global.rtc, 'change:status', function (model, status) {
          if (status === 'online') {
            _this.fetchMessages();
          }
        });

        if (global.rtc.get('status') === 'online') {
          _this.fetchMessages();
        }
      });

      _this.listenTo(_this, 'change:lastVersion', function (model, version) {
        AsyncStorage.setItem('history.lastVersion', version);
      });
    },

    fetchMessages: function () {
      if (!global.historyCollection.finishedLoading) {
        // can't load yet
        return;
      }
      var _this = this;
      var readItems = 0;
      var lastVersion = null;

      if (this.get('fetching')) {
        return;
      }

      this.set({ fetching: true });

      var fetchFromApi = function (from, page) {
        global.client.getUserHistory(from, _this.get('itemsPerPage'), page,
          function (err, response) {
            if (err) {
              return _this.trigger('error', err);
            }

            /*jshint camelcase: false */
            var items = response.call_records;
            if (!items.length) {
              return;
            }
            var version = items[0].call_record.history_version.value;
            var totalItems = response.total_results;
            /*jshint camelcase: true */

            readItems += items.length;

            if (page === 1) {
              // Update the version with the first result of the first page
              lastVersion = version;

              // Get the other pages in parallel
              var numPages = totalItems / _this.get('itemsPerPage');
              for (var i = 1; i < numPages; i++) {
                fetchFromApi(from, page + i);
              }
            }

            if (readItems >= totalItems) {
              _this.set({
                lastVersion: lastVersion,
                fetching: false
              });
            }

            // Filter text messages
            /*jshint camelcase: false */
            items = items.filter(function (message) {
              return (
                message.call_record.communication_type === 'text' &&
                message.call_record.deleted === false
              );
            });
            /*jshint camelcase: true */

            _this.trigger('messages', items.map(_this.parseMessage));
          });
      };

      fetchFromApi(this.get('lastVersion') ? this.get('lastVersion') : 0, 1);
    },

    parseMessage: function (message) {

      /*jshint camelcase: false */
      var content = message.attachments[0].data;
      var to = message.call_record.destination.phone_number;
      var from = message.call_record.source.phone_number;
      var commId = message.call_record.call_id;
      var date = message.call_record.start_time;
      var type = message.call_record.communication_type;
      var delivered = message.call_record.delivered;
      var deleted = message.call_record.deleted;
      var read = message.call_record.read;
      /*jshint camelcase: true */

      // Parse the date
      var d = date.match(/(\d{4})-(\d\d)-(\d\d) (\d\d):(\d\d):(\d\d)/);
      if (d) {
        d = new Date(Date.UTC(d[1], d[2] - 1, d[3], d[4], d[5], d[6]));
      }

      return {
        from: from,
        to: to,
        meta: {
          type: type,
          date: d,
          commId: commId,
          delivered: delivered,
          deleted: deleted,
          read: read
        },
        content: content
      };
    }
  });

  return HistoryFetcher;
});
