define([
  'backbone',
  'vendor/async-storage/async-storage'
], function (Backbone, AsyncStorage) {
  'use strict';

  var Message = Backbone.Model.extend({
    defaults: function () {
      return {
        type: 'text',
        meta: {},    // date, commId
        contents: '',
        from: {},
        counter: null,
        conversationId: null,
        status: 'pending'
      };
    },

    getStorageKey: function () {
      var key = null;
      var messageCounter = this.get('counter');
      if (this.get('conversationId') && messageCounter !== null) {
        key = 'msg:' + this.get('conversationId') + ':' + messageCounter;
      }
      return key;
    },

    saveToStorage: function (callback) {
      var key = this.getStorageKey();
      if (key) {
        AsyncStorage.setItem(key, this.attributes, function () {
          console.log('Saved message', key);
          if (callback) { callback(key); }
        });
      }
    },

    removeFromStorage: function (callback) {
      var key = this.getStorageKey();
      if (key) {
        AsyncStorage.removeItem(key, function () {
          console.log('Removed message', key);
          if (callback) { callback(key); }
        });
      }
    },

    unregister: function () {
      // Empty for now, but it's being called by the collection's unregister
    }

  }, {
    // static methods and vars
    loadFromStorage: function (key, callback) {
      AsyncStorage.getItem(key, function (value) {
        console.log('load message', key, (value ? 'OK' : 'FAIL'));
        callback(value ? new Message(value) : null);
      });
    }
  });

  return Message;
});
