define([
  'backbone'
], function (Backbone) {
  'use strict';

  var Contact = Backbone.Model.extend({
    defaults: function () {
      return {
        firstName: null,
        lastName: null,
        contactId: null,
        phone: null,
        email: null,
        isTumeUser: false,
        status: 'offline',
        photo: null
      };
    },

    getFormattedName: function () {
      var name = '';

      if (this.get('firstName') && this.get('lastName')) {
        name = this.get('firstName') + ' ' + this.get('lastName');
      }
      else {
        name = this.get('firstName') || this.get('lastName') || '';
      }

      return name;
    }
  });

  return Contact;
});
