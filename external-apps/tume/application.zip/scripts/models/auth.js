define([
  'backbone',
  'global',
  'storage/auth',
  'utils/connectivity'
], function (Backbone, global, authStorage, connectivity) {
  'use strict';

  var Auth = Backbone.Model.extend({
    defaults: function () {
      return {
        userId: null,
        password: null,
        loggedIn: null,
        msisdn: null,
        offlineLogged: null //only use if user is registered but offline
      };
    },

    initialize: function () {
      this.listenTo(this, 'change:userId', this._syncCredentials);
      this.listenTo(this, 'change:loggedIn', this._handleRefreshInterval);
      this.listenTo(connectivity, 'change:online', this.checkCredentials);
    },

    checkCredentials: function () {
      var _this = this;

      if (!this.get('userId')) {
        authStorage.load(function (userId, password, msisdn) {
          if (userId) {
            _this.tryToLogin(userId, password, msisdn);
          } else {
            _this.set({ loggedIn: false });
          }
        });
      } else if (!this.get('loggedIn')) {
        this.tryToLogin(
          this.get('userId'), this.get('password'), this.get('msisdn')
        );
      } else {
        // userId = true and loggedIn = true
        this.set({ offlineLogged: true, loggedIn: false });
      }
    },

    checkAppVersion: function (callback) {
      console.log('Invoking root call in API');
      global.client.root(this._parseErrs(callback));
    },

    register: function (phoneNumber, locale, callback) {
      global.client.register(phoneNumber, locale, this._parseErrs(callback));
    },

    validate: function (phone, pin, screenName, callback) {
      var _this = this;
      global.client.validate(phone, pin, screenName, this._parseErrs(
        function (err, result) {
          if (err) {
            return callback(err, result);
          }

          var params = _this._parseApiResults(result);
          params.msisdn = phone;
          _this.set(params);
          callback(null);
        }));
    },

    updateScreenName: function (screenName, callback) {
      var _this = this;
      /*jshint camelcase: false */
      global.client.updateUser({screen_name: screenName},
      /*jshint camelcase: true */
        this._parseErrs(function (err, result) {
          if (err) {
            return callback(err, result);
          }
          _this.set({ loggedIn: true });
          callback(null);
        }));
    },

    tryToLogin: function (userId, pass, msisdn) {
      if (!connectivity.get('online')) {
        return this.set({ offlineLogged: true, loggedIn: false });
      }

      this.login(userId, pass, msisdn);
    },

    login: function (userId, pass, msisdn) {
      // If there is a pending login retry, remove it
      // (so it's not executed twice)
      if (this.intervalLoginRetries) {
        window.clearInterval(this.intervalLoginRetries);
      }

      var _this = this;
      global.client.auth(userId, pass, this._parseErrs(function (err, result) {
        if (err) {
          _this.trigger('error error:login', err, result);
          if (typeof err === 'object' || err >= 500) {
            return _this._retryLoginBecauseOfErrors();
          }
          return _this.set('loggedIn', false);
        }

        global.client.refresh(_this._parseErrs(function (err, result) {
          if (err) {
            _this.trigger('error error:login', err, result);
            if (typeof err === 'object' || err >= 500) {
              return _this._retryLoginBecauseOfErrors();
            }
            return _this.set({
              loggedIn: false,
              offlineLogged: false
            });
          }

          var params = _this._parseApiResults(result);
          params.sipCredentials.password = pass;
          params.password = pass;
          params.msisdn = msisdn;
          _this.set(params);
          _this.set('loggedIn', true);
        }));
      }));
    },

    logout: function () {
      console.log('Logging out...');
      // The following will implicitely launch a redirect to login
      this.set({
        userId: null,
        password: null,
        loggedIn: false,
        msisdn: null
      });
    },

    _retryLoginBecauseOfErrors: function () {
      var _this = this;

      this.set({
        loggedIn: false,
        offlineLogged: true
      });

      console.log('Error in login. Retrying every 20 seconds...');

      this.intervalLoginRetries = window.setTimeout(function () {
        _this.checkCredentials();
      }, 20 * 1000);
    },

    _syncCredentials: function () {
      if (!this.get('userId')) {
        authStorage.clear();
      } else {
        authStorage.store(this.get('userId'), this.get('password'),
            this.get('msisdn'));
      }
    },

    _handleRefreshInterval: function () {
      var _this = this;
      if (this.get('loggedIn')) {
        this.refreshInterval = window.setInterval(function () {
          global.client.refresh(_this._parseErrs());
        }, 24 * 3600 * 1000);
      } else {
        window.clearInterval(this.refreshInterval);
      }
    },

    _parseApiResults: function (result) {
      // The API doesn't yet return the web sockets proxy address, so we
      // have to resort to hardcode it in global.js. When the API starts
      // returning it, it will override what is in global.js.
      var websocketsProxy = result.config.sip.wsproxy ||
          (global.clientConfig && global.clientConfig.wsProxy);

      return {
        /*jshint camelcase: false */
        userId: result.user.user_id,
        /*jshint camelcase: true */
        password: result.user.password,
        storageUrl: result.config.storage.url,
        sipCredentials: {
          username: result.config.sip.username,
          password: result.config.sip.password,
          domain: result.config.sip.domain,
          // TODO: Get from the API (it doesnt return it yet)
          server: websocketsProxy
        }
      };
    },

    _parseErrs: function (callback) {
      var _this = this;
      return function (err) {
        // TODO: Capture other type of errors (like connectivity errors)
        if (err === 426) {
          _this._redirectToMarketPlace();
        } else {
          if (callback && typeof(callback) === 'function') {
            callback.apply(_this, arguments);
          }
        }
      };
    },

    _redirectToMarketPlace: function () {
      console.log('Old app version. Redirecting to marketplace');
      window.location.href = 'https://marketplace.firefox.com/app/tu-me/';
    }
  });

  return Auth;
});
