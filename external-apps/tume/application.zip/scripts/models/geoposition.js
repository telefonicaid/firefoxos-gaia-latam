define([
  'backbone'
], function (Backbone) {
  'use strict';

  var GeoPosition = Backbone.Model.extend({
    defaults: function () {
      return {
        latitude: null,
        longitude: null
      };
    },

    update: function () {
      var _this = this;
      navigator.geolocation.getCurrentPosition(
        function (position) {
          _this.set({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude
          });
        },
        function (error) {
          _this.trigger('error', error);
        }
      );
    }
  });

  return GeoPosition;
});
