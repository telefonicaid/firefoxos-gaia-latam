define([
  'handlebars',
  'global'
], function (Handlebars, global) {
  'use strict';

  // returns a string with the formatted day of the date provided. It also
  // fuzzifies today and yesterday.
  // Examples for returned values:
  //  - 'today'
  //  - 'yesterday'
  //  - '12 Mar'
  function formatDay(date) {
    if (!date) { return ''; }

    var now = new Date();
    var yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    var day = null;

    if (now.toDateString() === date.toDateString()) {
      day = 'hoy';
    }
    else if (yesterday.toDateString() === date.toDateString()) {
      day = 'ayer';
    }
    else {
      // TODO: add support for multiple languages
      var months = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago',
      'Sep', 'Oct', 'Nov', 'Dic'];
      day = date.getDate() + ' ' + months[date.getMonth()];
    }

    return day;
  }

  var Helpers = {
    // returns a CSS class name for the owner of a message, depending on a
    // MSISDN.
    // returned values can be either 'me' or 'other'
    _messageOwnerClass: function (msisdn) {
      return global.auth.get('msisdn') === msisdn ? 'me' : 'other';
    },

    // returns a formatted date to show on messages in a conversation
    // returned examples: '12:01 Today', '06:34 Yesterday' or '21:30 12 Mar'
    _formattedMessageDate: function (messageDate) {
      if (!messageDate) { return ''; }
      var formattedDate = formatDay(messageDate);
      var formattedTime = /^\d\d:\d\d/.exec(messageDate.toTimeString());
      return formattedTime + ' ' + formattedDate;
    },

     // TODO: add support for multiple languages
    _localisedMessageStatus: function (status) {
      var res = '';

      switch (status) {
      case 'pending':
        res = 'pendiente';
        break;
      case 'sent':
        res = 'enviado';
        break;
      case 'unsent':
        res = 'sin enviar';
        break;
      }

      return res;
    },

    _ifIsUnsent: function (status, block) {
      return (status === 'unsent') ? block.fn(this) : block.inverse(this);
    },

    register: function () {
      Handlebars.registerHelper('messageOwnerClass', this._messageOwnerClass);
      Handlebars.registerHelper('formattedMessageDate',
        this._formattedMessageDate);
      Handlebars.registerHelper('localisedMessageStatus',
        this._localisedMessageStatus);
      Handlebars.registerHelper('ifIsUnsent', this._ifIsUnsent);
    }
  };

  return Helpers;
});
