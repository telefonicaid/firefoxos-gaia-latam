define(['vendor/async-storage/async-storage'], function (AsyncStorage) {
  'use strict';

  return {
    store: function (userId, password, msisdn, callback) {
      AsyncStorage.setItem('credentials', {
        userId: userId,
        password: password,
        msisdn: msisdn
      }, callback);
    },

    load: function (callback) {
      AsyncStorage.getItem('credentials', function (credentials) {
        var userId = null,
            password = null,
            msisdn = null;

        if (credentials) {
          userId = credentials.userId;
          password = credentials.password;
          msisdn = credentials.msisdn;
        }
        if (callback) {
          callback(userId, password, msisdn);
        }
      });
    },

    clear: function (callback) {
      AsyncStorage.removeItem('credentials', callback);
    }
  };
});
